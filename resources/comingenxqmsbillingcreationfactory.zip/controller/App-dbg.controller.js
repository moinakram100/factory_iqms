sap.ui.define([
  "sap/ui/core/mvc/Controller"
], (BaseController) => {
  "use strict";

  return BaseController.extend("com.ingenx.qms.billingcreation.controller.App", {
      onInit() {
      }
  });
});